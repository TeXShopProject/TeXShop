//
//  HelpController.m
//  TeXShop2
//
//  Created by Richard Koch on 6/9/16.
//  Copyright © 2016 Richard Koch. All rights reserved.
//

#import "HelpController.h"

@implementation HelpController


- (void)showTSHelp: (id)server
{
    
    NSURL * helpFile = [[NSBundle mainBundle] URLForResource:@"TexShop2" withExtension:@"rtf"];
    [helpEdit readRTFDFromFile: [helpFile path]];
    [helpWindow makeKeyAndOrderFront:self];
}


@end
