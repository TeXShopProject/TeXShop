//
//  HelpController.h
//  TeXShop2
//
//  Created by Richard Koch on 6/9/16.
//  Copyright © 2016 Richard Koch. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>


@interface HelpController : NSObject {
    IBOutlet NSWindow *helpWindow;
    IBOutlet NSTextView *helpEdit;
    
}

- (IBAction)showTSHelp: (id)server;

@end
