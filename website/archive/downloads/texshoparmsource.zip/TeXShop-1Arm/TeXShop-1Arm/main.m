//
//  main.m
//  TeXShop2
//
//  Created by Richard Koch on 6/4/16.
//  Copyright © 2016 Richard Koch. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
